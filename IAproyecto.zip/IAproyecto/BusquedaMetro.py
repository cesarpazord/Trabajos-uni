import metro 
class Nodo(): # creamos la clase y le agregamos el metodo construcutor 
    def __init__(self,nombre): # que sirve para inicializar las varibles nombre y vecinos
        self.nombre=nombre
        self.vecino=[]
        self.padre=None
        self.distancia=0
        self.color= ' '
    def AgreVecino(self,a): #cremos el metodo vecinos que es añadir a una lista el parametro a
          if not a in self.vecino: #Revisamos si el arista no se encuentra la lista de vecinos
               self.vecino.append(a)
    def __repr__(self):
         return self.nombre

class Grafo():
     def __init__(self): #inicialimos los vertices/nodos
       self.vertice={}

     def AgreVertice(self,nombreNodo): 
          nodo= Nodo(nombreNodo) 
          if nombreNodo not in self.vertice: #revisamos que el vertice aun no exista de lo contrario le pasamos nodo
               self.vertice[nombreNodo]= nodo #Creamos un nuevo nodo con una lista de vecinos/aristas vacia
                     
     def Arista(self,nombreN1,nombreN2):
          if(nombreN1 in self.vertice) and (nombreN2 in self.vertice): #revisamos si existen los nodos/vertices
               self.vertice[nombreN1].AgreVecino(self.vertice[nombreN2]) #ingresamos los objetos n1 y n2 
               self.vertice[nombreN2].AgreVecino(self.vertice[nombreN1]) #en su lista de vecinos, y viceversa 
          else:                                                           #creamos la arista de nombren2 a nombren1
           print(f"no existe el nodo {nombreN1} para agregarla arista {nombreN2}")

     def BFS(self,NodoInicial):
          for Vertices in self.vertice.values(): #recorremos en los valores y vamos integrando los aspectos del objeto
               Vertices.padre=None
               Vertices.color='blanco'
               Vertices.distancia=0
                                    # nIni es el nodo inicial
          VerticeInicio= self.vertice[NodoInicial] 
          VerticeInicio.color='gris'
          VerticeInicio.distancia=0
          VerticeInicio.padre=None
          cola=[]    #inicializamos las colas
          cola.append(VerticeInicio) #agregamos el nodo inicial a la cola
          while len(cola)>0: # comparamos que haya elementos en la cola
               explorando= cola.pop(0) 
               for vecinos in explorando.vecino: #Recorremos los vecinos del valor sacado de la cola
                    if vecinos.color== 'blanco': # comparamos si aun no a sido explorado
                         vecinos.color= 'gris'
                         vecinos.distancia= explorando.distancia + 1 
                         vecinos.padre=explorando #ponemos como padre a el indice retirado de la cola
                         cola.append(vecinos) 
               explorando.color= 'negro' #indicamos que ya fue explorado

     def DFS(self,NodoInicial): 
          for vertice in self.vertice.values(): #Recorremos y les damos sus caracterizticas
            vertice.padre=None
            vertice.color="blanco"
            vertice.distancia=-1
            
          verticeinicio=self.vertice[NodoInicial]#Obtenemos el vertice de nuestro nodo 
          verticeinicio.color="gris"
          verticeinicio.distancia=0
          self.DFS_visitar(verticeinicio) #Llamamos recursivamente a DFS
        
     def DFS_visitar(self,vertice):
         vertice.color="gris"  #decimos que esta en exploración
        
         for vecinos in vertice.vecino: #Recorremos los vecinos del vertice
            if vecinos.color == "blanco": #comparamos si aun no aes explorado el vecinos
               vecinos.padre=vertice #Asignamos como padre a nuestra llave que recorrimos en el for
               vecinos.color="gris"
               vecinos.distancia=vertice.distancia+1 #sumamos su distancia a 1
               self.DFS_visitar(vecinos)
            vecinos.color="negro"

     def ViajeBFS(self,NodoInicial,NodoFinal):
          resultado = f'Su viaje es de {NodoInicial} a {NodoFinal}\n' 
          print(f'Su viaje es de {NodoInicial} a {NodoFinal}')
          list=[] #Inicializamos una lista
          self.BFS(NodoInicial) 
          NumeroDeEstaciones=0
          Nodo= self.vertice[NodoFinal] 
          while Nodo!=None: 
               list.append(Nodo) #Vamos guardando el padre
               Nodo= Nodo.padre #Encontramos el padre y vamos recorriendolos hasta dar nulo
               NumeroDeEstaciones=NumeroDeEstaciones+1
          print(f'---En {NumeroDeEstaciones} estaciones con BFS---\n')
          resultado += f'---En {NumeroDeEstaciones} estaciones con BFS---\n'
          resultado += self.imprimirBFS(list)
          return self.imprimirBFS(list)
     
     def imprimirBFS(self, a):
          recorrido = ""
          for i in range(len(a)-1, -1, -1):
               recorrido += str(a[i]) + (" -> " if i != 0 else "")
          return recorrido


     def ViajeDFS(self,NodoInicial,NodoFinal):
          resultado = f'Su viaje es de {NodoInicial} a {NodoFinal}\n' 
          list=[]
          NumeroDeEstaciones=0
          self.DFS(NodoInicial)
          Nodo= self.vertice[NodoFinal]
          while Nodo!=None:
               list.append(Nodo) #Vamos guardando el padre
               Nodo= Nodo.padre #Encontramos el padre y vamos recorriendolos hasta dar nulo
               NumeroDeEstaciones=NumeroDeEstaciones+1
          print(f'---En {NumeroDeEstaciones} estaciones con DFS ---\n')  
          resultado += f'---En {NumeroDeEstaciones} estaciones con BFS---\n'
          resultado += self.imprimirDFS(list)
          return self.imprimirDFS(list)             
             
     
     def imprimirDFS(self,a):
          recorrido = ""
          for i in range(len(a)-1, -1, -1):
               recorrido += str(a[i]) + (" -> " if i != 0 else "")
          return recorrido   
                        
     def __repr__(self): #metodo de impresión
         vertix=self.vertice.keys() #.keys() es un metodo de los diccionarios para obtener todos los valores de las llaves
         imprimir=""    
         for ValorVerti in vertix:# valor verti va ir recorriendo los valores de los nodos/vertices y los vamos juntando con sus listas de vecinos
            imprimir = imprimir +'Vertice: '+ ValorVerti  +' sus aristas son: '+ str(self.vertice[ValorVerti].vecino) + "\n"
         return imprimir

GrafoMetro=Grafo() #creamos el objeto y sus vertices
def AgregarMetro(linea):#Creamos el grafo del metro
     for ValorLinea in linea: #recorremos la linea del metro 
           GrafoMetro.AgreVertice(ValorLinea) # Agregamos el vertice
     for i in range(len(linea)-1): #vamos recorriendo la linea
          GrafoMetro.Arista(linea[i],linea[i+1]) # Atraves de indices vamos agregando el nodo inicial(linea[i])
                                                 # nodo final(linea[i+1])
AgregarMetro(metro.linea1)
AgregarMetro(metro.linea2)
AgregarMetro(metro.linea3)
AgregarMetro(metro.linea4)
AgregarMetro(metro.linea5)
AgregarMetro(metro.linea6)
AgregarMetro(metro.linea7)
AgregarMetro(metro.linea8)
AgregarMetro(metro.linea9)
AgregarMetro(metro.lineaA)
AgregarMetro(metro.lineaB)
AgregarMetro(metro.linea12)
estacion1='Aquiles Serdán'
estacion2='Iztapalapa'
estacion3='San Antonio'
estacion4='Aragón'
estacion5='Vallejo'
estacion6='Insurgentes'
GrafoMetro.ViajeBFS(estacion5,estacion6)






