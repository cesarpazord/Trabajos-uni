
import tkinter as tk
from tkinter import messagebox, simpledialog
import datetime as dt
import urllib.request
import json

# Importaciones para funcionalidad del metro
import metro
from BusquedaMetro import GrafoMetro

def hora():
    return dt.datetime.now().strftime("%H:%M:%S")

def fecha():
    return dt.datetime.now().strftime("%d de %B de %Y")

API_KEY = "67c738e67932f54c5c071c50c57ca554"

respuestas = {
    'hola': '¡Hola! ¿Cómo estás?',
    'para que fuiste creado?': 'Fui creado para un trabajo de inteligencia artificial.',
    'quienes son mis creadores?': 'En sí por el ingenioso programador Renaldo, pero los números de cuenta de los creadores involucrados son:\n320101179.\n320341704.\n320118937.\n423064647.',
    'buenos dias': '¡Buenos días! Espero que tengas un gran día.',
    'buenas tardes': '¡Buenas tardes! ¿En qué puedo ayudarte?',
    'buenas noches': '¡Buenas noches! ¿Cómo te ha ido hoy?',
    'gracias': 'De nada, estoy aquí para ayudarte.',
    'necesito tu ayuda': '¡Por supuesto! ¿En qué puedo ayudarte?',
    'cual es tu nombre': 'Mi nombre es Chatbot.',
    'quién eres': 'Soy un chatbot diseñado para conversar contigo.',
    'dame la hora': hora(),
    'que hora es': hora(),
    'fecha': fecha(),
    'que dia es hoy': fecha(),
    'adios': 'Hasta luego, que tengas un buen día.',
    'bye': '¡Adiós! Nos vemos pronto.',
    'como estas': 'Estoy bien, gracias por preguntar. ¿Y tú?',
    'que puedes hacer': 'Puedo responder preguntas básicas, darte el clima, calcular operaciones y ayudarte con rutas del metro.',
    'cuentame un chiste': '¿Por qué los pájaros no usan Facebook? Porque ya tienen Twitter.',
    'como funciona este chatbot': 'Funciona con un diccionario de respuestas. Si escribes algo que no entiendo, puedo aprenderlo.',
    'quien te creo': 'Fui creado por un programador apasionado por la inteligencia artificial y se llama Renaldo.'
}

def enviar_mensaje():
    entrada = entrada_usuario.get().lower().strip()
    chat.insert(tk.END, f"Tú: {entrada}\n")

    respuesta = respuestas.get(entrada, None)
    if respuesta:
        chat.insert(tk.END, f"Chatbot: {respuesta if not callable(respuesta) else respuesta()}\n")
    else:
        respuesta_default = simpledialog.askstring("Aprendizaje", f"No entiendo '{entrada}'. ¿Quieres enseñarme una respuesta?")
        if respuesta_default:
            respuestas[entrada] = respuesta_default
            chat.insert(tk.END, f"Chatbot: ¡Gracias! Ahora sé responder a eso.\n")
        else:
            chat.insert(tk.END, "Chatbot: ¡Entendido! ¿Qué más quieres que haga?\n")

    entrada_usuario.delete(0, tk.END)

def calculadora():
    ventana_calc = tk.Toplevel(root)
    ventana_calc.title("Calculadora")
    ventana_calc.configure(bg="white")

    def operar(op):
        try:
            num1 = float(entry1.get())
            num2 = float(entry2.get())
            if op == "+":
                resultado.set(num1 + num2)
            elif op == "-":
                resultado.set(num1 - num2)
            elif op == "*":
                resultado.set(num1 * num2)
            elif op == "/":
                if num2 == 0:
                    messagebox.showerror("Error", "No se puede dividir entre cero.")
                else:
                    resultado.set(num1 / num2)
        except ValueError:
            messagebox.showerror("Error", "Introduce números válidos.")

    for label in ["Número 1:", "Número 2:", "Resultado:"]:
        tk.Label(ventana_calc, text=label, bg="white", fg="black").pack()

    entry1 = tk.Entry(ventana_calc, bg="white", fg="black", insertbackground='black')
    entry1.pack()
    entry2 = tk.Entry(ventana_calc, bg="white", fg="black", insertbackground='black')
    entry2.pack()

    resultado = tk.StringVar()
    tk.Label(ventana_calc, textvariable=resultado, bg="white", fg="black").pack()

    for operador in ["+", "-", "*", "/"]:
        tk.Button(ventana_calc, text=operador, command=lambda op=operador: operar(op),
                  bg="#f0f0f0", fg="black", font=("Arial", 10, "bold"),
                  activebackground="#d0d0d0", padx=10, pady=5).pack(pady=2)

def mostrar_clima():
    ciudad = simpledialog.askstring("Clima", "¿De qué ciudad quieres saber el clima?")
    if not ciudad:
        return

    ciudad_url = ciudad.replace(" ", "%20")
    url = f"http://api.openweathermap.org/data/2.5/weather?q={ciudad_url}&appid={API_KEY}&units=metric&lang=es"

    try:
        with urllib.request.urlopen(url) as response:
            datos = json.loads(response.read())

            clima = datos['weather'][0]['description']
            temperatura = datos['main']['temp']
            humedad = datos['main']['humidity']
            viento = datos['wind']['speed']

            resultado = (
                f"📍 Ciudad: {ciudad}\n"
                f"🌡 Temperatura: {temperatura}°C\n"
                f"🌥 Clima: {clima}\n"
                f"💧 Humedad: {humedad}%\n"
                f"🌬 Viento: {viento} m/s"
            )

            chat.insert(tk.END, f"Chatbot: {resultado}\n")
    except Exception as e:
        chat.insert(tk.END, f"Chatbot: No pude obtener el clima para '{ciudad}'. Verifica el nombre o tu conexión.\n")

def ruta_metro():
    origen = simpledialog.askstring("Metro CDMX", "Estación de origen:")
    destino = simpledialog.askstring("Metro CDMX", "Estación de destino:")
    if not origen or not destino:
        return

    if origen not in GrafoMetro.vertice or destino not in GrafoMetro.vertice:
        chat.insert(tk.END, "Chatbot: Una o ambas estaciones no son válidas. Intenta de nuevo.\n")
        return

    chat.insert(tk.END, f"Chatbot: Ruta desde {origen} hasta {destino} (BFS):\n")
    resultado_bfs = GrafoMetro.ViajeBFS(origen, destino)
    chat.insert(tk.END, f"Chatbot: {resultado_bfs}\n")
    chat.insert(tk.END, f"Chatbot: Exploración con DFS:\n")
    resultado_dfs = GrafoMetro.ViajeDFS(origen, destino)
    chat.insert(tk.END, f"Chatbot: {resultado_dfs}\n")

# Interfaz gráfica
root = tk.Tk()
root.title("Chatbot con Calculadora, Clima y Metro")
root.configure(bg="white")

chat = tk.Text(root, height=20, width=60, bg="white", fg="black", insertbackground='black')
chat.pack()

entrada_usuario = tk.Entry(root, width=40, bg="white", fg="black", insertbackground='black')
entrada_usuario.pack(side=tk.LEFT, padx=5, pady=10)

boton_estilo = {
    "bg": "#f0f0f0",
    "fg": "black",
    "activebackground": "#d0d0d0",
    "font": ("Arial", 10, "bold"),
    "bd": 1,
    "padx": 10,
    "pady": 5
}

tk.Button(root, text="Enviar", command=enviar_mensaje, **boton_estilo).pack(side=tk.LEFT, padx=5)
tk.Button(root, text="Calculadora", command=calculadora, **boton_estilo).pack(side=tk.LEFT, padx=5)
tk.Button(root, text="Clima", command=mostrar_clima, **boton_estilo).pack(side=tk.LEFT, padx=5)
tk.Button(root, text="Metro CDMX", command=ruta_metro, **boton_estilo).pack(side=tk.LEFT, padx=5)

root.mainloop()
